# TODO - FreeFire BR Bot Web Panel (Round 5)

## 1. EXP engine + level chart
- [x] Add levelchart.py (Free Fire 1-100 cumulative EXP table + helpers)
- [x] Auto-detect cumulative vs per-level exp model
- [x] Rewrite AccountSession exp tracking (base_total / total_exp / exp_gain)
- [x] Set base_exp once at add time; current exp live
- [x] Robust exp refresh (retry + re-login fallback) so exp is added for every ID

## 2. Match history
- [x] Track per-match start/end, duration, exp before/after, gain
- [x] Persist history to accounts.json
- [x] Expose history in public() + GET /api/accounts/{uid}/history
- [x] History button (left of delete) + history modal in UI

## 3. UI - CSS icons (no emoji)
- [x] Add mask-image based .ico icon set to style.css
- [x] Replace all emoji in index.html / dashboard.html / app.js / dashboard.js

## 4. UI - card metrics
- [x] Base EXP = value at add time, Current = live value
- [x] Progress bar + left label from level chart (in-level / need-next)
- [x] Right label = total exp / exp to reach next level
- [x] Keep exp/hr as secondary chip

## 5. UI - fix brightness blink
- [x] Stop replaying cardIn animation on every re-render
- [x] Keyed in-place card updates (no full innerHTML wipe)

## 6. Tests + deliver
- [x] Level chart + exp model unit tests
- [x] Manager exp/history tests
- [x] Server boots, endpoints 200
- [x] Repackage zip + README
