# -*- coding: utf-8 -*-
"""Free Fire level -> EXP chart (community chart, levels 1-100).

``CUM_EXP[L]`` is the **cumulative** EXP required to *reach* level ``L``.
The per-level requirement to advance from ``L`` to ``L+1`` is
``CUM_EXP[L+1] - CUM_EXP[L]`` (the chart's "XP/LVL" column).

The game client reports the profile EXP in one of two ways depending on the
build / region:

* **cumulative** - the total EXP since level 1 (always increases), or
* **per-level**  - the EXP gained inside the current level (resets to a small
  value on every level-up).

:func:`resolve_total` turns either reading into a single *cumulative* number so
that EXP gain can be tracked safely across level-ups, and auto-detects which
model an account uses.
"""

# Cumulative EXP needed to reach each level (chart "EXP NEEDED" column).
_CUM = {
    1: 0, 2: 100, 3: 300, 4: 600, 5: 1000, 6: 1500, 7: 2100, 8: 2800, 9: 3600,
    10: 4500, 11: 5500, 12: 6600, 13: 7800, 14: 9100, 15: 10500, 16: 12000,
    17: 13600, 18: 15300, 19: 17100, 20: 19000, 21: 21000, 22: 23100, 23: 25300,
    24: 27600, 25: 30000, 26: 32500, 27: 35100, 28: 37800, 29: 40600, 30: 43500,
    31: 46500, 32: 49600, 33: 52800, 34: 56100, 35: 59500, 36: 63000, 37: 66600,
    38: 70300, 39: 74100, 40: 78000, 41: 82000, 42: 86100, 43: 90300, 44: 94600,
    45: 99000, 46: 103500, 47: 108100, 48: 112800, 49: 117600, 50: 122500,
    51: 127500, 52: 132600, 53: 137800, 54: 143100, 55: 148500, 56: 154000,
    57: 159600, 58: 165300, 59: 171100, 60: 177000, 61: 183000, 62: 189100,
    63: 195300, 64: 201600, 65: 208000, 66: 214500, 67: 221100, 68: 227800,
    69: 234600, 70: 241500, 71: 248500, 72: 255600, 73: 262800, 74: 270100,
    75: 277500, 76: 285000, 77: 292600, 78: 300300, 79: 308100, 80: 316000,
    81: 324000, 82: 332100, 83: 340300, 84: 348600, 85: 357000, 86: 365500,
    87: 374100, 88: 382800, 89: 391600, 90: 400500, 91: 409500, 92: 418600,
    93: 427800, 94: 437100, 95: 446500, 96: 456000, 97: 465600, 98: 475300,
    99: 485100, 100: 495000,
}

MAX_LEVEL = 100

# Cumulative EXP for the chart's "100+" row; used as the anchor for levels > 100.
_LEVEL_101 = 1031669
# Per-level growth used to extrapolate past level 100 (kept close to the 100->101
# jump so the progress bar never divides by zero / explodes).
_LEVEL_101_SPAN = 9900

# Model identifiers
MODEL_UNKNOWN = "unknown"
MODEL_CUMULATIVE = "cumulative"
MODEL_PER_LEVEL = "per_level"


def cum_exp(level) -> int:
    """Cumulative EXP required to *reach* ``level`` (>= 1)."""
    try:
        level = int(level)
    except (TypeError, ValueError):
        level = 1
    if level <= 1:
        return 0
    if level <= MAX_LEVEL:
        return _CUM[level]
    # Extrapolate past level 100.
    return _LEVEL_101 + (level - 101) * _LEVEL_101_SPAN


def level_span(level) -> int:
    """EXP required to advance from ``level`` to ``level + 1``."""
    span = cum_exp(_as_level(level) + 1) - cum_exp(level)
    return max(1, span)


def level_from_total(total) -> int:
    """Highest level whose cumulative requirement is <= ``total``."""
    try:
        total = int(total)
    except (TypeError, ValueError):
        total = 0
    total = max(0, total)
    if total >= _LEVEL_101:
        return 101 + (total - _LEVEL_101) // _LEVEL_101_SPAN
    lvl = 1
    while lvl < MAX_LEVEL and _CUM[lvl + 1] <= total:
        lvl += 1
    return lvl


def _as_level(level) -> int:
    try:
        level = int(level)
    except (TypeError, ValueError):
        level = 1
    return max(1, level)


def resolve_total(level, exp, model=MODEL_UNKNOWN):
    """Return ``(cumulative_total, model)`` for a ``(level, exp)`` reading.

    Auto-detects whether ``exp`` is cumulative or per-level:

    * per-level EXP is always **less than** the level span, and
    * cumulative EXP is always **at least** the level floor,

    and for every level >= 3 the floor is >= the span, so the two ranges never
    overlap and the model can be detected reliably.  Levels 1-2 are ambiguous
    (level 1 has floor 0, level 2's ranges overlap) so the previously detected
    model is kept there.
    """
    level = _as_level(level)
    try:
        exp = int(exp)
    except (TypeError, ValueError):
        exp = 0
    exp = max(0, exp)

    floor = cum_exp(level)
    span = level_span(level)

    if level >= 3:
        if exp < span:
            model = MODEL_PER_LEVEL
        elif exp >= floor:
            model = MODEL_CUMULATIVE

    if model not in (MODEL_PER_LEVEL, MODEL_CUMULATIVE):
        model = MODEL_CUMULATIVE

    if model == MODEL_PER_LEVEL:
        total = floor + exp
    else:
        # cumulative: guard against a stray reading below the level floor
        total = exp if exp >= floor else floor + exp
    return total, model


def progress(level, total_exp):
    """Return ``(in_level, span, pct)`` progress inside ``level``.

    ``in_level`` is the EXP gained since reaching ``level`` and ``span`` is the
    EXP still required to reach ``level + 1``.
    """
    level = _as_level(level)
    floor = cum_exp(level)
    ceil = cum_exp(level + 1)
    span = max(1, ceil - floor)
    try:
        total_exp = int(total_exp)
    except (TypeError, ValueError):
        total_exp = floor
    in_level = max(0, min(span, total_exp - floor))
    pct = round(min(100.0, (in_level / span) * 100.0), 1)
    return in_level, span, pct
