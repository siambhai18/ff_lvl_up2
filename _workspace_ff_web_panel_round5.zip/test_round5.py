# -*- coding: utf-8 -*-
"""Round 5 tests.

  A. levelchart: cumulative table, level spans, level_from_total, the
     cumulative/per-level auto-detection and the progress helper.
  B. manager: base-EXP freeze, harvested gain across level-ups, level_progress
     and per-match history (duration + EXP gained) incl. persistence.
  C. server: boots with a mocked botcore, auth + accounts + history endpoints
     return the right codes and payloads.
"""
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import levelchart
import manager as manager_mod
from manager import AccountSession

passed = 0
failed = 0


def check(name, cond, extra=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        print(f"  [FAIL] {name} {extra}")


# =========================================================================== #
# A. level chart
# =========================================================================== #
print("== A. Level chart ==")
check("cum_exp(1) == 0", levelchart.cum_exp(1) == 0)
check("cum_exp(2) == 100", levelchart.cum_exp(2) == 100)
check("cum_exp(10) == 4500", levelchart.cum_exp(10) == 4500)
check("cum_exp(100) == 495000", levelchart.cum_exp(100) == 495000)
check("level_span(1) == 100", levelchart.level_span(1) == 100)
check("level_span(2) == 200", levelchart.level_span(2) == 200)
check("level_span(10) == 1000", levelchart.level_span(10) == 1000)
check("level_from_total(0) == 1", levelchart.level_from_total(0) == 1)
check("level_from_total(100) == 2", levelchart.level_from_total(100) == 2)
check("level_from_total(4499) == 9", levelchart.level_from_total(4499) == 9)
check("level_from_total(4500) == 10", levelchart.level_from_total(4500) == 10)
check("level_from_total(495000) == 100", levelchart.level_from_total(495000) == 100)

# auto-detection: level 10 (floor 4500, span 1000)
tot, model = levelchart.resolve_total(10, 200)
check("per-level detected (200 < span)", model == levelchart.MODEL_PER_LEVEL and tot == 4700, f"{tot},{model}")
tot, model = levelchart.resolve_total(10, 4700)
check("cumulative detected (>= floor)", model == levelchart.MODEL_CUMULATIVE and tot == 4700, f"{tot},{model}")
tot, model = levelchart.resolve_total(10, 4500)
check("cumulative at floor", model == levelchart.MODEL_CUMULATIVE and tot == 4500, f"{tot},{model}")

in_lvl, span, pct = levelchart.progress(10, 4500)
check("progress at floor -> 0%", (in_lvl, span, pct) == (0, 1000, 0.0), f"{in_lvl},{span},{pct}")
in_lvl, span, pct = levelchart.progress(10, 5000)
check("progress halfway -> 50%", (in_lvl, span, pct) == (500, 1000, 50.0), f"{in_lvl},{span},{pct}")
in_lvl, span, pct = levelchart.progress(10, 5500)
check("progress at ceil -> 100%", (in_lvl, span, pct) == (1000, 1000, 100.0), f"{in_lvl},{span},{pct}")


# =========================================================================== #
# B. manager exp + history
# =========================================================================== #
print("== B. Manager exp tracking ==")

# --- base freeze (cumulative model) ---
s = AccountSession("111", "pw", "ME", "alice")
s.update_exp(1200, 5)
check("base frozen at add time", s.base_exp == 1200 and s.base_total == 1200)
check("gain starts at 0", s.exp_gain == 0)
s.update_exp(1500, 5)
check("base stays frozen after gain", s.base_exp == 1200 and s.base_total == 1200)
check("gain computed from frozen base", s.exp_gain == 300, s.exp_gain)
check("current exp is live", s.last_exp == 1500 and s.total_exp == 1500)

# --- per-level model + level-up ---
s2 = AccountSession("222", "pw", "ME", "alice")
s2.update_exp(100, 10)
check("per-level model detected", s2.exp_model == levelchart.MODEL_PER_LEVEL, s2.exp_model)
check("per-level total = floor + exp", s2.total_exp == 4600, s2.total_exp)
s2.update_exp(400, 10)
check("per-level gain within level", s2.exp_gain == 300, s2.exp_gain)
s2.update_exp(50, 11)  # level-up: raw exp resets
check("gain survives a level-up", s2.exp_gain == 950, s2.exp_gain)

# --- level_progress ---
s3 = AccountSession("333", "pw", "ME", "alice")
s3.update_exp(5000, 10)
p = s3.level_progress()
check("progress level", p["level"] == 10 and p["next_level"] == 11)
check("progress floor/ceil", p["level_floor"] == 4500 and p["level_ceil"] == 5500)
check("progress in-level", p["exp_in_level"] == 500 and p["exp_for_next"] == 1000)
check("progress pct", p["progress_pct"] == 50.0, p["progress_pct"])

pub = s3.public()
for field in ("base_exp", "exp_current", "exp_total", "level_floor", "level_ceil",
              "next_level", "exp_in_level", "exp_for_next", "progress_pct",
              "exp_model", "history", "history_count"):
    check(f"public() exposes {field}", field in pub)

# --- per-match history ---
s4 = AccountSession("444", "pw", "ME", "alice")
s4.update_exp(5000, 10)
s4.start_match_record({"match_index": 1, "server_ip_port": "1.2.3.4:9999", "region": "ME"})
check("current_match opened", s4.current_match is not None)
time.sleep(0.05)
s4.update_exp(5300, 10)  # +300 during the match
entry = s4.finish_match_record({"match_index": 1})
check("history entry exp_before", entry["exp_before"] == 5000, entry["exp_before"])
check("history entry exp_after", entry["exp_after"] == 5300, entry["exp_after"])
check("history entry exp_gain", entry["exp_gain"] == 300, entry["exp_gain"])
check("history entry duration > 0", entry["duration"] > 0, entry["duration"])
check("history entry index", entry["index"] == 1)
check("total_matches incremented", s4.total_matches == 1)
check("history length 1", len(s4.match_history) == 1)
check("current_match cleared", s4.current_match is None)

# --- persistence round-trip ---
TMP = tempfile.mkdtemp()
manager_mod.DATA_DIR = TMP
manager_mod.DATA_FILE = os.path.join(TMP, "accounts.json")

mgr = manager_mod.AccountManager()
mgr.accounts["alice::555"] = s4
s4.uid = "555"
mgr._save()
mgr2 = manager_mod.AccountManager()
saved = mgr2.get("alice", "555")
check("account reloaded from disk", saved is not None)
check("base_exp persisted", saved and saved.base_exp == 5000)
check("total_exp persisted", saved and saved.total_exp == 5300)
check("exp_gain persisted", saved and saved.exp_gain == 300)
check("history persisted", saved and len(saved.match_history) == 1)
check("history exp_gain persisted", saved and saved.match_history[0]["exp_gain"] == 300)
check("manager.history() returns list", mgr2.history("alice", "555") is not None)
check("manager.history() unknown -> None", mgr2.history("alice", "nope") is None)


# =========================================================================== #
# C. server endpoints (mocked botcore)
# =========================================================================== #
print("== C. Server endpoints ==")
import botcore  # noqa: E402
import server  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


async def fake_process(uid, password, region=None):
    return {
        "account_id": uid,
        "nickname": f"Player_{uid}",
        "region": (region or "ME").upper(),
        "level": 10,
        "exp": 5000,
        "functional_addrs": "1.2.3.4:10000",
        "informational_addrs": None,
        "client_version": "1.0",
        "token": "tok",
        "server_time": 0,
        "aes_ak": b"0" * 16,
        "iv_i": b"0" * 16,
    }


botcore.process_account_uid_pass = fake_process

SRV_TMP = tempfile.mkdtemp()
manager_mod.DATA_DIR = SRV_TMP
manager_mod.DATA_FILE = os.path.join(SRV_TMP, "accounts.json")
server.manager.accounts = {}
server.users.path = os.path.join(SRV_TMP, "users.json")
server.users.users = {}
server.users.sessions = {}

client = TestClient(server.app)

r = client.get("/login", follow_redirects=False)
check("GET /login -> 200", r.status_code == 200)

r = client.post("/api/auth/register", json={"username": "carol", "password": "secret1"})
check("register -> 200", r.status_code == 200 and r.json().get("ok"))

r = client.post("/api/accounts", json={"uid": "777777", "password": "p", "region": "ME"})
check("add account -> 200", r.status_code == 200 and r.json()["account"]["uid"] == "777777")
acc = r.json()["account"]
check("account base_exp == 5000", acc["base_exp"] == 5000, acc.get("base_exp"))
check("account exp_current == 5000", acc["exp_current"] == 5000)
check("account exp_gain == 0", acc["exp_gain"] == 0)

r = client.get("/api/accounts/777777/history")
check("history endpoint -> 200", r.status_code == 200)
check("history count 0", r.json()["count"] == 0 and r.json()["history"] == [])

r = client.get("/api/accounts/does-not-exist/history")
check("history unknown uid -> 404", r.status_code == 404)

# simulate a finished match directly on the session
sess = server.manager.accounts["carol::777777"]
sess.start_match_record({"match_index": 1, "server_ip_port": "1.2.3.4:9", "region": "ME"})
sess.update_exp(5400, 10)
sess.finish_match_record({"match_index": 1})
server.manager._save()

r = client.get("/api/accounts/777777/history")
check("history endpoint -> 1 match", r.status_code == 200 and r.json()["count"] == 1)
h = r.json()["history"][0]
check("history payload exp_gain == 400", h["exp_gain"] == 400, h.get("exp_gain"))
check("history payload has duration", "duration" in h and "started_at" in h)

r = client.get("/api/accounts")
acc = r.json()["accounts"][0]
check("list shows base vs current", acc["base_exp"] == 5000 and acc["exp_current"] == 5400, (acc["base_exp"], acc["exp_current"]))
check("list shows harvested gain", acc["exp_gain"] == 400, acc["exp_gain"])
check("list shows progress fields", "exp_in_level" in acc and "exp_for_next" in acc and "progress_pct" in acc)

r = client.get("/")
check("GET / (authed) -> 200", r.status_code == 200 and "histOverlay" in r.text)
check("index references icons.css", "/static/icons.css" in r.text)

r = client.get("/dashboard")
check("GET /dashboard -> 200", r.status_code == 200)

print(f"\nRESULT: {passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
