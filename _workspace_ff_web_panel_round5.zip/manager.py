# -*- coding: utf-8 -*-
"""
Account manager for the FreeFire BR web panel.

Holds accounts (scoped per panel-user), performs login/profile fetch, and
controls the BR match session per account with live status reporting
(idle -> matchmaking -> in_game).

Round 5 additions:
  * level-chart based EXP tracking (base / current / progress toward next level)
  * base EXP is frozen at the moment the account is added
  * per-match history (duration + EXP gained) with a dedicated endpoint
  * robust EXP refresh (retry + re-login fallback) so EXP is credited for
    every account, even after the login token expires
"""
import asyncio
import json
import os
import time
from typing import Dict, List, Optional, Callable, Awaitable

import botcore
import levelchart

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DATA_FILE = os.path.join(DATA_DIR, "accounts.json")

VALID_REGIONS = ["ME", "IND", "SG", "TH", "PH", "VN", "MY", "ID", "HK", "TW",
                 "BD", "PK", "CIS", "BR", "NA", "SAC", "EUROPE"]

# statuses
ST_IDLE = "idle"
ST_LOGGING_IN = "logging_in"
ST_READY = "ready"
ST_MATCHMAKING = "matchmaking"
ST_IN_GAME = "in_game"
ST_ERROR = "error"
ST_STOPPED = "stopped"

MAX_HISTORY = 200  # keep the last N matches per account


def _key(owner: str, uid: str) -> str:
    """Accounts are stored per owner; anonymous (owner == '') keeps legacy keys."""
    owner = (owner or "").strip().lower()
    uid = str(uid).strip()
    return f"{owner}::{uid}" if owner else uid


def _to_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


class AccountSession:
    def __init__(self, uid: str, password: str, region: str = "ME", owner: str = ""):
        self.uid = str(uid).strip()
        self.password = password
        self.region = (region or "ME").upper()
        self.owner = (owner or "").strip().lower()
        self.account_data: Optional[Dict] = None
        self.status = ST_IDLE
        self.error: Optional[str] = None
        self.logs: List[Dict] = []
        self.task: Optional[asyncio.Task] = None
        self.stop_event: Optional[asyncio.Event] = None
        self.last_update = time.time()

        # --- exp tracking (chart based) ---
        self.exp_model = levelchart.MODEL_UNKNOWN   # cumulative | per_level
        self.last_exp: Optional[int] = None         # last raw exp reading
        self.last_level: Optional[int] = None       # last level reading
        self.total_exp: Optional[int] = None        # current cumulative exp
        # base = frozen at the moment the account was added
        self.base_exp: Optional[int] = None         # raw exp at add time
        self.base_level: Optional[int] = None
        self.base_total: Optional[int] = None       # cumulative exp at add time
        self.base_at: Optional[float] = None        # when the base was captured
        self.exp_gain: int = 0                      # total_exp - base_total
        self.total_matches: int = 0
        self.session_started_at: float = time.time()

        # --- current match tracking (for the live timer + reconnect) ---
        self.match_started_at: Optional[float] = None
        self.match_info: Optional[Dict] = None
        self.in_match: bool = False
        self.current_match: Optional[Dict] = None   # in-progress match snapshot
        self.match_history: List[Dict] = []         # finished matches

    # ------------------------------------------------------------------ exp
    def update_exp(self, exp, level=None):
        """Record a fresh (level, exp) reading and refresh the gain counters.

        Works for both the cumulative and per-level EXP models thanks to
        :func:`levelchart.resolve_total`.
        """
        exp_i = _to_int(exp)
        if exp_i is None or exp_i < 0:
            return
        if level is None:
            level = (self.account_data or {}).get("level")
        level_i = _to_int(level, self.last_level)
        if level_i is None:
            level_i = 1

        total, model = levelchart.resolve_total(level_i, exp_i, self.exp_model)
        self.exp_model = model
        self.last_exp = exp_i
        self.last_level = level_i
        self.total_exp = total

        # Freeze the base the first time we ever see this account.
        if self.base_total is None:
            self.base_exp = exp_i
            self.base_level = level_i
            self.base_total = total
            self.base_at = time.time()

        # Recompute the base total with the *current* model so a model change
        # never corrupts the harvested total.
        base_total, _ = levelchart.resolve_total(
            self.base_level, self.base_exp, self.exp_model
        )
        self.base_total = base_total
        self.exp_gain = max(0, total - base_total)

    def exp_per_hour(self) -> float:
        started = self.base_at or self.session_started_at
        elapsed = max(1.0, time.time() - started)
        return round(self.exp_gain / (elapsed / 3600.0), 1)

    def level_progress(self) -> Dict:
        level = self.last_level
        if level is None:
            level = _to_int((self.account_data or {}).get("level"), 1) or 1
        total = self.total_exp
        if total is None:
            total = levelchart.cum_exp(level)
        in_level, span, pct = levelchart.progress(level, total)
        return {
            "level": level,
            "next_level": level + 1,
            "level_floor": levelchart.cum_exp(level),
            "level_ceil": levelchart.cum_exp(level + 1),
            "exp_total": total,
            "exp_in_level": in_level,
            "exp_for_next": span,
            "progress_pct": pct,
        }

    # -------------------------------------------------------------- history
    def start_match_record(self, info: Optional[Dict]):
        info = info or {}
        self.current_match = {
            "index": info.get("match_index"),
            "started_at": info.get("started_at") or time.time(),
            "server": info.get("server_ip_port"),
            "region": info.get("region") or self.region,
            "exp_before": self.total_exp,
            "exp_before_raw": self.last_exp,
            "level_before": self.last_level,
        }

    def finish_match_record(self, info: Optional[Dict] = None) -> Optional[Dict]:
        """Close the in-progress match, append it to the history and return it."""
        info = info or {}
        cur = self.current_match or {}
        started = cur.get("started_at") or info.get("started_at") or time.time()
        ended = time.time()
        before = cur.get("exp_before")
        after = self.total_exp
        if before is not None and after is not None:
            gain = max(0, after - before)
        else:
            gain = 0
        entry = {
            "index": cur.get("index") if cur.get("index") is not None else info.get("match_index"),
            "started_at": started,
            "ended_at": ended,
            "duration": round(max(0.0, ended - started), 1),
            "exp_before": before,
            "exp_after": after,
            "exp_gain": gain,
            "level_before": cur.get("level_before"),
            "level_after": self.last_level,
            "server": cur.get("server") or info.get("server_ip_port"),
            "region": cur.get("region") or info.get("region") or self.region,
        }
        self.match_history.append(entry)
        if len(self.match_history) > MAX_HISTORY:
            self.match_history = self.match_history[-MAX_HISTORY:]
        self.total_matches += 1
        self.current_match = None
        return entry

    # --------------------------------------------------------------- public
    def public(self) -> Dict:
        ad = self.account_data or {}
        running = bool(self.task and not self.task.done())
        # Prefer the live reading (set by update_exp) so "current exp" is always
        # the freshest value, falling back to the cached login blob.
        level = self.last_level if self.last_level is not None else _to_int(ad.get("level"))
        exp = self.last_exp if self.last_exp is not None else _to_int(ad.get("exp"))
        prog = self.level_progress()
        base_exp = self.base_exp if self.base_exp is not None else exp
        return {
            "uid": self.uid,
            "name": ad.get("nickname") or "",
            "account_id": str(ad.get("account_id") or ""),
            "level": level,
            "exp": exp,
            "base_exp": base_exp,
            "exp_current": exp,
            "exp_total": prog["exp_total"],
            "base_total": self.base_total,
            "level_floor": prog["level_floor"],
            "level_ceil": prog["level_ceil"],
            "next_level": prog["next_level"],
            "exp_in_level": prog["exp_in_level"],
            "exp_for_next": prog["exp_for_next"],
            "progress_pct": prog["progress_pct"],
            "exp_model": self.exp_model,
            "exp_gain": self.exp_gain,
            "exp_per_hour": self.exp_per_hour(),
            "total_matches": self.total_matches,
            "region": ad.get("region") or self.region,
            "status": self.status,
            "error": self.error,
            "running": running,
            "in_match": self.in_match,
            "match_started_at": self.match_started_at,
            "match_index": (self.match_info or {}).get("match_index"),
            "history": self.match_history[-40:],
            "history_count": len(self.match_history),
            "logs": self.logs[-60:],
        }


class AccountManager:
    def __init__(self):
        self.accounts: Dict[str, AccountSession] = {}
        self._listeners: List[Callable[[Dict], Awaitable[None]]] = []
        self._load()

    # ---------------- persistence ----------------
    def _load(self):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            for a in data:
                uid = str(a.get("uid", "")).strip()
                if not uid:
                    continue
                owner = str(a.get("owner", "")).strip().lower()
                s = AccountSession(uid, a.get("password", ""), a.get("region", "ME"), owner)
                # restore stats / last-known match (so we can reconnect after a restart)
                try:
                    s.exp_model = a.get("exp_model") or levelchart.MODEL_UNKNOWN
                    if a.get("last_exp") is not None:
                        s.last_exp = int(a.get("last_exp"))
                    if a.get("last_level") is not None:
                        s.last_level = int(a.get("last_level"))
                    if a.get("total_exp") is not None:
                        s.total_exp = int(a.get("total_exp"))
                    if a.get("base_exp") is not None:
                        s.base_exp = int(a.get("base_exp"))
                    if a.get("base_level") is not None:
                        s.base_level = int(a.get("base_level"))
                    if a.get("base_total") is not None:
                        s.base_total = int(a.get("base_total"))
                    if a.get("base_at") is not None:
                        s.base_at = float(a.get("base_at"))
                    s.exp_gain = int(a.get("exp_gain") or 0)
                    s.total_matches = int(a.get("total_matches") or 0)
                    if isinstance(a.get("match_history"), list):
                        s.match_history = a.get("match_history")
                    if a.get("match_info"):
                        s.match_info = a.get("match_info")
                        s.match_started_at = s.match_info.get("started_at")
                except Exception:
                    pass
                self.accounts[_key(owner, uid)] = s
        except Exception:
            pass

    def _save(self):
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            payload = [
                {
                    "owner": s.owner,
                    "uid": s.uid,
                    "password": s.password,
                    "region": s.region,
                    "exp_model": s.exp_model,
                    "last_exp": s.last_exp,
                    "last_level": s.last_level,
                    "total_exp": s.total_exp,
                    "base_exp": s.base_exp,
                    "base_level": s.base_level,
                    "base_total": s.base_total,
                    "base_at": s.base_at,
                    "exp_gain": s.exp_gain,
                    "total_matches": s.total_matches,
                    "match_info": s.match_info,
                    "match_history": s.match_history,
                }
                for s in self.accounts.values()
            ]
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            pass

    # ---------------- listeners / broadcast ----------------
    def add_listener(self, cb):
        self._listeners.append(cb)

    def remove_listener(self, cb):
        try:
            self._listeners.remove(cb)
        except ValueError:
            pass

    async def broadcast(self, msg: Dict):
        for cb in list(self._listeners):
            try:
                await cb(msg)
            except Exception:
                pass

    async def _emit_account(self, session: AccountSession):
        await self.broadcast({"type": "account", "owner": session.owner, "account": session.public()})

    def _log(self, session: AccountSession, msg: str):
        entry = {"t": time.time(), "msg": msg}
        session.logs.append(entry)
        if len(session.logs) > 300:
            session.logs = session.logs[-300:]
        # avoid spamming the socket with the very chatty debug lines
        if "[DEBUG]" in msg:
            return
        try:
            asyncio.get_running_loop().create_task(
                self.broadcast({"type": "log", "owner": session.owner, "uid": session.uid,
                                "msg": msg, "t": entry["t"]})
            )
        except Exception:
            pass

    async def _set_status(self, session: AccountSession, status: str):
        if session.status != status:
            session.status = status
            session.last_update = time.time()
            await self.broadcast({"type": "status", "owner": session.owner,
                                  "uid": session.uid, "status": status})

    # ---------------- account CRUD ----------------
    def _owned(self, owner: str) -> List[AccountSession]:
        owner = (owner or "").strip().lower()
        return [s for s in self.accounts.values() if s.owner == owner]

    def list_public(self, owner: str = "") -> List[Dict]:
        return [s.public() for s in self._owned(owner)]

    def get(self, owner: str, uid: str) -> Optional[AccountSession]:
        return self.accounts.get(_key(owner, uid))

    def history(self, owner: str, uid: str) -> Optional[List[Dict]]:
        session = self.accounts.get(_key(owner, uid))
        if not session:
            return None
        return list(session.match_history)

    def dashboard(self, owner: str = "") -> Dict:
        accs = self._owned(owner)
        levels = []
        total_exp = 0
        for s in accs:
            lv = s.last_level
            if lv is None:
                lv = _to_int((s.account_data or {}).get("level"))
            if isinstance(lv, (int, float)) and lv > 0:
                levels.append(int(lv))
            total_exp += int(s.total_exp or 0)
        in_match = sum(1 for s in accs if s.in_match or s.status == ST_IN_GAME)
        matchmaking = sum(1 for s in accs if s.status == ST_MATCHMAKING)
        online = sum(1 for s in accs if s.status == ST_READY)
        paused = sum(1 for s in accs if s.status in (ST_IDLE, ST_STOPPED))
        errors = sum(1 for s in accs if s.status == ST_ERROR)
        running = sum(1 for s in accs if s.task and not s.task.done())
        return {
            "total_accounts": len(accs),
            "total_exp_gained": sum(s.exp_gain for s in accs),
            "total_matches": sum(s.total_matches for s in accs),
            "total_exp": total_exp,
            "in_match": in_match,
            "matchmaking": matchmaking,
            "online": online,
            "paused": paused,
            "errors": errors,
            "running": running,
            "avg_level": round(sum(levels) / len(levels), 1) if levels else 0,
            "max_level": max(levels) if levels else 0,
            "accounts": [s.public() for s in accs],
        }

    async def add_account(self, owner: str, uid: str, password: str, region: str = "ME") -> Dict:
        uid = str(uid).strip()
        if not uid:
            raise ValueError("UID is required")
        if not password:
            raise ValueError("Password is required")
        region = (region or "ME").upper()
        if region not in VALID_REGIONS:
            region = "ME"

        key = _key(owner, uid)
        session = self.accounts.get(key)
        if session is None:
            session = AccountSession(uid, password, region, owner)
            self.accounts[key] = session
        else:
            session.password = password
            session.region = region
        self._save()

        await self._emit_account(session)
        # fetch details (login) right away -> this also freezes the base exp
        await self.login_account(owner, uid)
        return session.public()

    async def remove_account(self, owner: str, uid: str):
        key = _key(owner, uid)
        session = self.accounts.get(key)
        if not session:
            return
        await self.stop_match(owner, uid)
        self.accounts.pop(key, None)
        self._save()
        await self.broadcast({"type": "removed", "owner": session.owner, "uid": session.uid})

    async def login_account(self, owner: str, uid: str) -> Dict:
        session = self.accounts.get(_key(owner, uid))
        if not session:
            raise ValueError("Account not found")
        if session.task and not session.task.done():
            # already running a session
            return session.public()

        session.error = None
        await self._set_status(session, ST_LOGGING_IN)
        self._log(session, f"[*] Fetching profile for UID {session.uid} ...")
        try:
            data = await botcore.process_account_uid_pass(
                session.uid, session.password, session.region
            )
        except Exception as e:
            data = None
            self._log(session, f"[-] Login error: {e}")

        if not data:
            session.error = "Login failed (wrong UID/password or server error)"
            await self._set_status(session, ST_ERROR)
            self._log(session, f"[-] Login failed for UID {session.uid}")
            await self._emit_account(session)
            return session.public()

        session.account_data = data
        session.error = None
        session.update_exp(data.get("exp"), data.get("level"))
        self._save()
        await self._set_status(session, ST_READY)
        self._log(
            session,
            f"[+] Login OK | {data.get('nickname')} | UID {data.get('account_id')} "
            f"| Lvl {data.get('level')} | Exp {data.get('exp')} | Region {data.get('region')}",
        )
        await self._emit_account(session)
        return session.public()

    # ---------------- exp refresh helpers ----------------
    async def _refresh_exp(self, session: AccountSession, retries: int = 3,
                           delay: float = 2.0, allow_relogin: bool = True) -> bool:
        """Best-effort fresh EXP fetch.

        Tries ``refresh_account_profile`` a few times; if it keeps failing (e.g.
        the login token expired) it re-logs-in so EXP keeps being credited for
        every account.
        """
        for attempt in range(retries):
            try:
                await botcore.refresh_account_profile(session.account_data)
                ad = session.account_data or {}
                if ad.get("exp") is not None:
                    session.update_exp(ad.get("exp"), ad.get("level"))
                    return True
            except Exception:
                pass
            if attempt < retries - 1:
                await asyncio.sleep(delay)

        if allow_relogin:
            try:
                data = await botcore.process_account_uid_pass(
                    session.uid, session.password, session.region
                )
                if data:
                    session.account_data = data
                    session.error = None
                    session.update_exp(data.get("exp"), data.get("level"))
                    self._log(session, "[i] Re-logged in to refresh EXP.")
                    return True
            except Exception:
                pass
        return False

    # ---------------- match control ----------------
    def _match_info_recent(self, info: Optional[Dict]) -> bool:
        """A stored match is only worth reconnecting to if it is still recent."""
        try:
            started = float((info or {}).get("started_at") or 0)
        except (TypeError, ValueError):
            return False
        if started <= 0:
            return False
        return (time.time() - started) < botcore.MAX_MATCH_DURATION

    async def start_match(self, owner: str, uid: str) -> Dict:
        session = self.accounts.get(_key(owner, uid))
        if not session:
            raise ValueError("Account not found")

        # 1) The session is already running.
        if session.task and not session.task.done():
            if session.in_match:
                # Already inside a match -> do NOT start a new one, just make sure
                # we keep the existing match alive (reconnect + pings).
                idx = (session.match_info or {}).get("match_index", "?")
                self._log(
                    session,
                    f"[~] UID {session.uid} is already in match #{idx} - "
                    f"reconnecting & sending pings (no new match started).",
                )
                await self._emit_account(session)
                return session.public()
            # matchmaking / logging in -> a session is already active
            self._log(
                session,
                f"[i] UID {session.uid} session already active ({session.status}).",
            )
            return session.public()

        # 2) Not running, but we remember a recent match -> try to reconnect to it.
        if session.match_info and self._match_info_recent(session.match_info):
            session.stop_event = asyncio.Event()
            session.task = asyncio.create_task(self._run_reconnect(session))
            await self._emit_account(session)
            return session.public()

        # 3) Fresh start: login if needed then run a normal BR session.
        if not session.account_data:
            await self.login_account(owner, uid)
            if not session.account_data:
                return session.public()

        # NOTE: the EXP baseline for the first match comes from the last reading
        # (login / previous match). Every finished match re-reads EXP, so the
        # per-match gain stays accurate without an extra pre-match round-trip.

        session.stop_event = asyncio.Event()
        session.task = asyncio.create_task(self._run_session(session))
        await self._emit_account(session)
        return session.public()

    async def _run_reconnect(self, session: AccountSession):
        """Try to reconnect to the account's last known match. If the match is
        gone, fall back to starting a normal BR session."""
        info = dict(session.match_info or {})
        self._log(session, f"[~] Reconnecting UID {session.uid} to existing match ...")
        await self._set_status(session, ST_MATCHMAKING)
        await self._emit_account(session)

        async def status_cb(st):
            await self._set_status(session, st)
            await self._emit_account(session)

        def log_cb(msg):
            self._log(session, msg)

        try:
            result = await botcore.reconnect_match(
                info, status_cb=status_cb, log_cb=log_cb, stop_event=session.stop_event
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self._log(session, f"[-] Reconnect error: {e}")
            result = "no-match"

        if session.stop_event and session.stop_event.is_set():
            session.in_match = False
            session.match_started_at = None
            await self._set_status(session, ST_READY if session.account_data else ST_IDLE)
            await self._emit_account(session)
            return

        if result == "reconnected":
            # the match we reconnected to finished -> count it and start a new one
            await self._refresh_exp(session)
            session.start_match_record(info)
            session.finish_match_record(info)
            self._log(
                session,
                f"[+] Reconnected match finished. Total matches: {session.total_matches}",
            )
        else:
            self._log(session, "[i] No live match to reconnect to - starting a fresh match.")

        # clear the (now stale) match and continue with a normal persistent session
        session.in_match = False
        session.match_started_at = None
        session.match_info = None
        self._save()
        await self._emit_account(session)

        await self._run_session(session)

    async def stop_match(self, owner: str, uid: str) -> Dict:
        session = self.accounts.get(_key(owner, uid))
        if not session:
            raise ValueError("Account not found")
        if session.stop_event:
            session.stop_event.set()
        if session.task and not session.task.done():
            session.task.cancel()
            try:
                await session.task
            except (asyncio.CancelledError, Exception):
                pass
        session.task = None
        # stop the live timer, but keep match_info so that pressing Start again
        # can reconnect to the same match if it is still live on the server.
        session.in_match = False
        session.match_started_at = None
        self._save()
        await self._set_status(session, ST_READY if session.account_data else ST_IDLE)
        await self._emit_account(session)
        return session.public()

    async def _run_session(self, session: AccountSession):
        """Persistent session: keeps playing BR matches, auto re-logs in on drop,
        until the user presses Stop."""
        while True:
            if session.stop_event and session.stop_event.is_set():
                break
            try:
                retry = await self._run_once(session)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                session.error = str(e)
                self._log(session, f"[-] Session error: {e}")
                retry = True

            if session.stop_event and session.stop_event.is_set():
                break
            if not retry:
                break

            # Session dropped on its own -> reconnect automatically (auto BR)
            self._log(session, "[!] Session dropped. Reconnecting in 3s...")
            await self._set_status(session, ST_LOGGING_IN)
            await asyncio.sleep(3)
            try:
                data = await botcore.process_account_uid_pass(
                    session.uid, session.password, session.region
                )
                if data:
                    session.account_data = data
                    session.error = None
                    session.update_exp(data.get("exp"), data.get("level"))
                    await self._emit_account(session)
            except Exception:
                pass

        await self._set_status(session, ST_READY if session.account_data else ST_IDLE)
        await self._emit_account(session)

    async def _run_once(self, session: AccountSession):
        ad = session.account_data
        reg = ad.get("region") or session.region
        acc_id = str(ad.get("account_id"))
        func_addr = ad.get("functional_addrs")
        info_addr = ad.get("informational_addrs")

        info_task = None
        exp_task = None
        try:
            if not func_addr or ":" not in str(func_addr):
                session.error = "No match server address returned by login"
                await self._set_status(session, ST_ERROR)
                self._log(session, f"[-] {session.error} (functional_addrs missing)")
                await self._emit_account(session)
                return False

            tcp_online = await botcore.build_tcp_startup_packet(
                ad["account_id"], ad["token"], ad["server_time"],
                ad["aes_ak"], ad["iv_i"], region=reg, typ="OnLine",
            )
            tcp_chat = await botcore.build_tcp_startup_packet(
                ad["account_id"], ad["token"], ad["server_time"],
                ad["aes_ak"], ad["iv_i"], region=reg, typ="ChaT",
            )

            if info_addr and ":" in str(info_addr):
                info_task = asyncio.create_task(
                    botcore.informational(
                        info_addr, tcp_chat, ad["aes_ak"], ad["iv_i"],
                        region=reg, account_id=acc_id,
                    )
                )

            exp_task = asyncio.create_task(self._exp_refresher(session))

            async def status_cb(st):
                if st == "connected":
                    st = ST_MATCHMAKING
                await self._set_status(session, st)
                await self._emit_account(session)

            def log_cb(msg):
                self._log(session, msg)

            async def match_cb(event, info):
                if event == "start":
                    session.match_info = dict(info or {})
                    session.in_match = True
                    session.match_started_at = (info or {}).get("started_at") or time.time()
                    session.start_match_record(info)
                    self._log(
                        session,
                        f"[+] Match #{(info or {}).get('match_index')} started "
                        f"at {(info or {}).get('server_ip_port')} - timer running.",
                    )
                    self._save()
                    await self._emit_account(session)
                elif event == "end":
                    session.in_match = False
                    session.match_started_at = None
                    session.match_info = None
                    # refresh EXP (with retry + re-login fallback) so the gain is
                    # always credited, even if the token expired mid-match.
                    await self._refresh_exp(session)
                    entry = session.finish_match_record(info)
                    self._log(
                        session,
                        f"[+] Match #{entry.get('index')} finished in "
                        f"{entry.get('duration')}s | +{entry.get('exp_gain')} EXP "
                        f"| Total matches: {session.total_matches} "
                        f"| Harvested: {session.exp_gain}",
                    )
                    self._save()
                    await self._emit_account(session)

            await botcore.functional_br(
                func_addr,
                tcp_online,
                reg,
                ad["client_version"],
                ad["aes_ak"],
                ad["iv_i"],
                account_id=acc_id,
                account_data=ad,
                status_cb=status_cb,
                log_cb=log_cb,
                stop_event=session.stop_event,
                single_match=False,
                match_cb=match_cb,
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            session.error = str(e)
            self._log(session, f"[-] Session error: {e}")
        finally:
            for t in (info_task, exp_task):
                if t and not t.done():
                    t.cancel()
            for t in (info_task, exp_task):
                if t:
                    try:
                        await t
                    except (asyncio.CancelledError, Exception):
                        pass
        return True

    async def _exp_refresher(self, session: AccountSession):
        while True:
            await asyncio.sleep(120)
            try:
                if await self._refresh_exp(session, retries=2, allow_relogin=True):
                    await self._emit_account(session)
            except Exception:
                pass

    async def shutdown(self):
        for key in list(self.accounts.keys()):
            s = self.accounts.get(key)
            if not s:
                continue
            try:
                await self.stop_match(s.owner, s.uid)
            except Exception:
                pass
