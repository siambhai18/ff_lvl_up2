/* =========================================================================
   FreeFire BR Bot Panel - accounts page logic
   -------------------------------------------------------------------------
   Round 5:
     * pure-CSS icons (no emoji)
     * Base EXP (frozen at add time) vs Current EXP (live)
     * progress bar driven by the Free Fire level chart
         - left label : EXP gained inside the current level / EXP to next
         - right label: current total EXP / total EXP to reach next level
     * per-match History button + modal
     * keyed in-place card updates so live websocket pushes never replay the
       card animation (this is what used to make the page "blink")
   ========================================================================= */
const state = {
  accounts: {},   // uid -> account object
  regions: [],
  filter: "all",
  search: "",
  user: null,
  openLogs: {},   // uid -> bool
};

/* uid -> live card element (keyed rendering) */
const cardEls = {};

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s)
  .replace(/&/g, "\u0026amp;").replace(/</g, "\u0026lt;").replace(/>/g, "\u0026gt;")
  .replace(/"/g, "\u0026quot;");
const fmt = (n) => {
  if (n === null || n === undefined || n === "") return "0";
  const num = Number(n);
  if (isNaN(num)) return String(n);
  return num.toLocaleString("en-US");
};
const initials = (a) => {
  const s = (a.name || a.uid || "?").trim();
  return (s[0] || "?").toUpperCase();
};
const ico = (name) => `<span class="ico ico-${name}"></span>`;

/* ------------------------- toast ------------------------- */
let toastTimer = null;
function toast(msg, kind) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show " + (kind || "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast " + (kind || "")), 2600);
}

/* ------------------------- api ------------------------- */
async function api(path, opts) {
  const res = await fetch(path, Object.assign(
    { headers: { "Content-Type": "application/json" } }, opts));
  if (res.status === 401) { window.location.href = "/login"; throw new Error("unauth"); }
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.detail) || res.statusText);
  return data;
}

/* ------------------------- status helpers ------------------------- */
const STATUS_LABEL = {
  idle: "PAUSED", stopped: "PAUSED", logging_in: "LOGGING IN",
  ready: "ONLINE", matchmaking: "MATCHMAKING", in_game: "IN MATCH", error: "ERROR",
};
function statusClass(a) {
  if (a.in_match) return "in_game";
  return a.status || "idle";
}
function statusText(a) {
  const c = statusClass(a);
  return STATUS_LABEL[c] || c.toUpperCase();
}

/* ------------------------- confirm modal ------------------------- */
let modalResolve = null;
function openConfirm(opts) {
  $("modalIcon").innerHTML = ico(opts.icon || "warning");
  $("modalIcon").className = "modal-icon" + (opts.danger ? " danger" : "");
  $("modalTitle").textContent = opts.title || "Are you sure?";
  $("modalText").innerHTML = opts.text || "";
  const ok = $("modalConfirm");
  ok.textContent = opts.confirm || "Confirm";
  ok.className = "btn" + (opts.danger ? " danger" : "");
  $("modalOverlay").classList.add("show");
  return new Promise((resolve) => { modalResolve = resolve; });
}
function closeConfirm(val) {
  $("modalOverlay").classList.remove("show");
  if (modalResolve) { modalResolve(val); modalResolve = null; }
}
$("modalCancel").addEventListener("click", () => closeConfirm(false));
$("modalConfirm").addEventListener("click", () => closeConfirm(true));
$("modalOverlay").addEventListener("click", (e) => {
  if (e.target === $("modalOverlay")) closeConfirm(false);
});

/* ------------------------- history modal ------------------------- */
function fmtDur(sec) {
  sec = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m ${String(s).padStart(2, "0")}s`;
}
function fmtTime(ts) {
  if (!ts) return "\u2014";
  try { return new Date(ts * 1000).toLocaleString(); } catch (e) { return "\u2014"; }
}
function renderHistory(hist) {
  hist = hist || [];
  const totalGain = hist.reduce((s, h) => s + (h.exp_gain || 0), 0);
  const totalDur = hist.reduce((s, h) => s + (h.duration || 0), 0);
  const avgGain = hist.length ? Math.round(totalGain / hist.length) : 0;

  $("histSummary").innerHTML = `
    <div class="hs"><div class="k">Matches</div><div class="v">${fmt(hist.length)}</div></div>
    <div class="hs"><div class="k">Total EXP</div><div class="v g">+${fmt(totalGain)}</div></div>
    <div class="hs"><div class="k">Avg / match</div><div class="v c">+${fmt(avgGain)}</div></div>`;

  const listEl = $("histList");
  if (!hist.length) {
    listEl.innerHTML = `<div class="hist-empty">${ico("history")}No matches played yet.<br/>Start a session to build match history.</div>`;
    return;
  }
  listEl.innerHTML = hist.slice().reverse().map((h) => {
    const g = h.exp_gain || 0;
    const idx = h.index != null ? h.index : "\u2013";
    let lv = "";
    if (h.level_before != null && h.level_after != null) {
      lv = h.level_after > h.level_before
        ? `LVL${h.level_before}\u2192${h.level_after}`
        : `LVL${h.level_after}`;
    } else if (h.level_after != null) {
      lv = `LVL${h.level_after}`;
    }
    return `<div class="hist-item">
      <div class="hbadge">#${esc(idx)}</div>
      <div class="hmain">
        <div class="htitle">${g > 0 ? "+" + fmt(g) + " EXP gained" : "No EXP change"}</div>
        <div class="hsub">
          <span class="mi">${ico("clock")}${esc(fmtDur(h.duration))}</span>
          <span class="mi">${ico("chart")}${esc(fmt(h.exp_before))} \u2192 ${esc(fmt(h.exp_after))}</span>
          ${lv ? `<span class="mi">${ico("trend")}${esc(lv)}</span>` : ""}
        </div>
        <div class="hsub"><span class="mi">${esc(fmtTime(h.started_at))}</span></div>
      </div>
      <div class="hright"><div class="hg ${g > 0 ? "" : "zero"}">+${fmt(g)}</div></div>
    </div>`;
  }).join("");
}
async function openHistory(uid) {
  const a = state.accounts[uid] || {};
  $("histTitle").textContent = (a.name || uid) + " \u2014 Match History";
  $("histSub").textContent = "UID " + uid;
  $("histOverlay").classList.add("show");
  $("histSummary").innerHTML = "";
  $("histList").innerHTML = `<div class="hist-empty">Loading\u2026</div>`;
  let hist = a.history || [];
  try {
    const r = await api(`/api/accounts/${uid}/history`);
    hist = r.history || hist;
  } catch (e) { /* fall back to the cached copy */ }
  renderHistory(hist);
}
function closeHistory() { $("histOverlay").classList.remove("show"); }
$("histClose").addEventListener("click", closeHistory);
$("histOverlay").addEventListener("click", (e) => {
  if (e.target === $("histOverlay")) closeHistory();
});

/* ------------------------- rendering ------------------------- */
function matchesFilter(a) {
  const f = state.filter;
  if (f === "all") return true;
  if (f === "match") return a.in_match || a.status === "in_game" || a.status === "matchmaking";
  if (f === "online") return a.status === "ready";
  if (f === "paused") return ["idle", "stopped", "error"].includes(a.status) && !a.in_match;
  return true;
}
function matchesSearch(a) {
  const q = state.search.trim().toLowerCase();
  if (!q) return true;
  return (a.uid || "").toLowerCase().includes(q) || (a.name || "").toLowerCase().includes(q);
}

/* Static skeleton for one card - created once, then patched in place. */
function cardHTML(a) {
  return `
  <div class="card enter" data-uid="${esc(a.uid)}">
    <div class="card-top">
      <div class="avatar" data-f="avatar">${esc(initials(a))}</div>
      <div class="who">
        <div class="name"><span data-f="name">${esc(a.name || "Unknown")}</span> <span class="region-badge" data-f="region">${esc(a.region || "ME")}</span></div>
        <div class="uid">UID: ${esc(a.uid)}</div>
      </div>
      <div class="status-pill" data-f="status"></div>
    </div>

    <div class="stats">
      <div class="stat base"><span class="k">${ico("shield")}Base EXP</span><span class="v" data-f="base">0</span></div>
      <div class="stat cur"><span class="k">${ico("sparkle")}Current</span><span class="v" data-f="cur">0</span></div>
      <div class="stat harv"><span class="k">${ico("trend")}Harvested</span><span class="v pos" data-f="gain">+0</span></div>
    </div>

    <div class="lvl-row">
      <span class="lvl" data-f="lvl">LVL\u2013</span>
      <span class="arrow">\u2192</span>
      <span class="lvl" data-f="nextlvl">LVL\u2013</span>
      <span class="spacer"></span>
      <span class="total-exp" title="Current EXP / EXP needed to reach the next level">${ico("gauge")}<span data-f="total">0</span><span class="sep">/</span><span data-f="ceil">0</span></span>
    </div>
    <div class="progress"><div class="bar" data-f="bar" style="width:0%"></div></div>
    <div class="prog-meta">
      <span class="left" title="EXP gained this level / EXP needed for the next level">${ico("chart")}<span data-f="inlevel">0</span>&nbsp;/&nbsp;<span data-f="fornext">0</span>&nbsp;to next</span>
      <span class="right"><span class="rate" title="Average EXP per hour">${ico("bolt")}<span data-f="rate">0</span>/hr</span><span class="pct" data-f="pct">0%</span></span>
    </div>

    <div class="match-timer hidden" data-f="timerwrap">
      <span class="lbl">${ico("clock")}Match time</span>
      <span class="timer" data-f="timer" data-start="">00:00</span>
      <span class="lbl">&middot; matches: <span data-f="matches1">0</span></span>
    </div>
    <div class="match-timer hidden" data-f="totalwrap">
      <span class="lbl">${ico("trophy")}Total matches played</span>
      <span data-f="matches2">0</span>
    </div>

    <div class="actions">
      <button class="act primary" data-act="start" data-f="runbtn" title="Start">${ico("play")}</button>
      <button class="act" data-act="refresh" title="Refresh profile">${ico("refresh")}</button>
      <button class="act" data-act="logs" title="Logs">${ico("list")}</button>
      <button class="act hist" data-act="history" title="Match history">${ico("history")}</button>
      <button class="act del" data-act="remove" title="Remove">${ico("trash")}</button>
    </div>

    <div class="logs-panel hidden" data-logs="${esc(a.uid)}"></div>
  </div>`;
}

function fillLogs(el, a) {
  const lp = el.querySelector(`.logs-panel[data-logs="${a.uid}"]`);
  if (!lp) return;
  lp.innerHTML = (a.logs || []).slice(-40).map((l) => `<div class="ln">${esc(l.msg)}</div>`).join("")
    || '<div class="ln">No logs yet.</div>';
  lp.classList.toggle("hidden", !state.openLogs[a.uid]);
}

/* Patch an existing card element with fresh account data (no re-render). */
function patchCard(el, a) {
  const set = (f, val) => { const n = el.querySelector(`[data-f="${f}"]`); if (n) n.textContent = val; };
  const running = !!a.running;

  const base = a.base_exp != null ? a.base_exp : a.exp;
  const current = a.exp_current != null ? a.exp_current : a.exp;
  const gain = a.exp_gain || 0;
  const level = a.level != null ? a.level : "\u2013";
  const nextLevel = a.next_level != null ? a.next_level
    : ((typeof a.level === "number") ? a.level + 1 : "\u2013");
  const inLevel = a.exp_in_level != null ? a.exp_in_level : 0;
  const forNext = a.exp_for_next != null ? a.exp_for_next : 0;
  const pct = Number(a.progress_pct || 0);
  const total = a.exp_total != null ? a.exp_total : current;
  const ceil = a.level_ceil != null ? a.level_ceil : total;

  const sp = el.querySelector('[data-f="status"]');
  if (sp) { sp.className = "status-pill " + statusClass(a); sp.textContent = statusText(a); }

  set("avatar", initials(a));
  set("name", a.name || "Unknown");
  set("region", a.region || "ME");
  set("base", fmt(base));
  set("cur", fmt(current));
  set("gain", "+" + fmt(gain));
  set("lvl", "LVL" + level);
  set("nextlvl", "LVL" + nextLevel);
  set("total", fmt(total));
  set("ceil", fmt(ceil));
  set("inlevel", fmt(inLevel));
  set("fornext", fmt(forNext));
  set("rate", fmt(a.exp_per_hour));
  set("pct", pct.toFixed(1) + "%");

  const bar = el.querySelector('[data-f="bar"]');
  if (bar) bar.style.width = Math.max(0, Math.min(100, pct)).toFixed(1) + "%";

  /* match timer */
  const tw = el.querySelector('[data-f="timerwrap"]');
  if (tw) tw.classList.toggle("hidden", !a.in_match);
  const timer = el.querySelector('[data-f="timer"]');
  if (timer) {
    timer.setAttribute("data-start", a.match_started_at || "");
    if (!a.in_match) timer.textContent = "00:00";
  }
  set("matches1", fmt(a.total_matches));
  set("matches2", fmt(a.total_matches));
  const totalWrap = el.querySelector('[data-f="totalwrap"]');
  if (totalWrap) totalWrap.classList.toggle("hidden", !(!a.in_match && a.total_matches));

  /* run / stop button */
  const rb = el.querySelector('[data-f="runbtn"]');
  if (rb) {
    rb.className = "act " + (running ? "stop" : "primary");
    rb.setAttribute("data-act", running ? "stop" : "start");
    rb.setAttribute("title", running ? "Stop" : "Start");
    rb.innerHTML = ico(running ? "pause" : "play");
  }
}

function render() {
  const all = Object.values(state.accounts);
  const list = all.filter(matchesFilter).filter(matchesSearch);

  /* counts */
  $("cAll").textContent = all.length;
  $("cMatch").textContent = all.filter((a) => a.in_match || a.status === "in_game" || a.status === "matchmaking").length;
  $("cOnline").textContent = all.filter((a) => a.status === "ready").length;
  $("cPaused").textContent = all.filter((a) => ["idle", "stopped", "error"].includes(a.status) && !a.in_match).length;

  const wrap = $("accounts");
  const emptyEl = $("empty");

  if (!list.length) {
    Object.keys(cardEls).forEach((uid) => { cardEls[uid].remove(); delete cardEls[uid]; });
    emptyEl.style.display = "block";
    if (all.length && (state.search || state.filter !== "all")) {
      emptyEl.querySelector("h3").textContent = "No matches";
      emptyEl.querySelector("p").innerHTML = "Try a different search or filter.";
    } else {
      emptyEl.querySelector("h3").textContent = "No accounts yet";
      emptyEl.querySelector("p").innerHTML = "Add a FreeFire UID above to fetch its profile,<br/>then press play to start an auto BR match.";
    }
    updateGlobalStatus();
    return;
  }
  emptyEl.style.display = "none";

  const wanted = new Set(list.map((a) => a.uid));
  /* drop cards that are no longer visible */
  Object.keys(cardEls).forEach((uid) => {
    if (!wanted.has(uid)) { cardEls[uid].remove(); delete cardEls[uid]; }
  });

  /* create new / patch existing, in order (appendChild reorders without
     restarting CSS animations, so the page never blinks) */
  list.forEach((a) => {
    let el = cardEls[a.uid];
    if (!el) {
      const tpl = document.createElement("template");
      tpl.innerHTML = cardHTML(a).trim();
      el = tpl.content.firstElementChild;
      cardEls[a.uid] = el;
      fillLogs(el, a);
    }
    patchCard(el, a);
    wrap.appendChild(el);
  });

  updateGlobalStatus();
  updateTimers();
}

function updateGlobalStatus() {
  const all = Object.values(state.accounts);
  const running = all.filter((a) => a.running).length;
  const inMatch = all.filter((a) => a.in_match).length;
  const errs = all.filter((a) => a.status === "error").length;
  const wrap = $("globalStatusWrap");
  const label = $("globalStatus");
  wrap.className = "global-status";
  if (errs) { wrap.classList.add("err"); label.textContent = errs + " error" + (errs > 1 ? "s" : ""); }
  else if (inMatch) { wrap.classList.add("live"); label.textContent = inMatch + " in match"; }
  else if (running) { wrap.classList.add("busy"); label.textContent = running + " active"; }
  else { label.textContent = all.length ? "Idle" : "No accounts"; }
}

/* ------------------------- live timers ------------------------- */
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = (x) => String(x).padStart(2, "0");
  return h > 0 ? `${p(h)}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
}
function updateTimers() {
  const now = Date.now() / 1000;
  document.querySelectorAll(".timer[data-start]").forEach((el) => {
    const start = parseFloat(el.getAttribute("data-start"));
    if (!start) { el.textContent = "00:00"; return; }
    el.textContent = fmtClock(now - start);
  });
}
setInterval(updateTimers, 1000);

/* ------------------------- actions ------------------------- */
async function doStart(uid) {
  try {
    const r = await api(`/api/accounts/${uid}/start`, { method: "POST" });
    if (r.account) state.accounts[uid] = r.account;
    toast("Match started", "ok"); render();
  } catch (e) { toast(e.message, "err"); }
}
async function doStop(uid) {
  const a = state.accounts[uid] || {};
  const ok = await openConfirm({
    icon: "pause", danger: true,
    title: "Stop match?",
    text: `Stop the BR session for <b>${esc(a.name || uid)}</b>?<br/>The bot will leave the match and stop pinging.`,
    confirm: "Stop match",
  });
  if (!ok) return;
  try {
    const r = await api(`/api/accounts/${uid}/stop`, { method: "POST" });
    if (r.account) state.accounts[uid] = r.account;
    toast("Match stopped", "ok"); render();
  } catch (e) { toast(e.message, "err"); }
}
async function doRefresh(uid) {
  toast("Refreshing profile...");
  try {
    const r = await api(`/api/accounts/${uid}/login`, { method: "POST" });
    if (r.account) state.accounts[uid] = r.account;
    toast("Profile refreshed", "ok"); render();
  } catch (e) { toast(e.message, "err"); }
}
async function doRemove(uid) {
  const a = state.accounts[uid] || {};
  const ok = await openConfirm({
    icon: "trash", danger: true,
    title: "Remove account?",
    text: `Remove <b>${esc(a.name || uid)}</b> (UID ${esc(uid)}) from the panel?<br/>This cannot be undone.`,
    confirm: "Remove",
  });
  if (!ok) return;
  try {
    await api(`/api/accounts/${uid}`, { method: "DELETE" });
    delete state.accounts[uid];
    toast("Account removed", "ok"); render();
  } catch (e) { toast(e.message, "err"); }
}

$("accounts").addEventListener("click", (e) => {
  const btn = e.target.closest("[data-act]");
  if (!btn) return;
  const card = e.target.closest(".card");
  if (!card) return;
  const uid = card.getAttribute("data-uid");
  const act = btn.getAttribute("data-act");
  if (act === "start") doStart(uid);
  else if (act === "stop") doStop(uid);
  else if (act === "refresh") doRefresh(uid);
  else if (act === "remove") doRemove(uid);
  else if (act === "history") openHistory(uid);
  else if (act === "logs") {
    state.openLogs[uid] = !state.openLogs[uid];
    const panel = card.querySelector(`.logs-panel[data-logs="${uid}"]`);
    if (panel) panel.classList.toggle("hidden", !state.openLogs[uid]);
  }
});

/* ------------------------- add account ------------------------- */
$("addHead").addEventListener("click", () => $("addPanel").classList.toggle("open"));
$("addForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const uid = $("uid").value.trim();
  const password = $("password").value;
  const region = $("region").value;
  if (!uid || !password) { toast("UID and password required", "err"); return; }
  const btn = $("addBtn");
  btn.disabled = true; btn.textContent = "Fetching profile...";
  try {
    const r = await api("/api/accounts", {
      method: "POST",
      body: JSON.stringify({ uid, password, region }),
    });
    if (r.account) state.accounts[r.account.uid] = r.account;
    $("uid").value = ""; $("password").value = "";
    toast("Account added", "ok");
    render();
  } catch (err) {
    toast(err.message, "err");
  } finally {
    btn.disabled = false; btn.textContent = "Add & Fetch Profile";
  }
});

/* ------------------------- upload accounts JSON ------------------------- */
$("uploadForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const file = $("accountsJson").files[0];
  const btn = $("uploadBtn");
  const result = $("uploadResult");
  if (!file) { toast("Select a JSON file first", "err"); return; }
  if (!file.name.toLowerCase().endsWith(".json")) {
    toast("Please select a .json file", "err");
    return;
  }

  btn.disabled = true;
  btn.textContent = "Importing and logging in...";
  result.textContent = "";
  try {
    const raw = await file.text();
    let accounts;
    try { accounts = JSON.parse(raw); }
    catch (_) { throw new Error("The selected file is not valid JSON"); }
    if (!Array.isArray(accounts)) throw new Error("JSON must be an array of account objects");

    const r = await api("/api/accounts/import", {
      method: "POST",
      body: JSON.stringify(accounts),
    });
    const fresh = await api("/api/accounts");
    state.accounts = {};
    (fresh.accounts || []).forEach((a) => (state.accounts[a.uid] = a));
    render();

    const summary = document.createElement("div");
    summary.className = r.failed ? "err" : "ok";
    summary.textContent = `Import finished: ${r.success} succeeded, ${r.failed} failed (of ${r.total}).`;
    result.appendChild(summary);

    (r.results || []).filter((item) => !item.ok).forEach((item) => {
      const line = document.createElement("div");
      line.className = "err";
      line.textContent = `#${item.index}${item.uid ? " UID " + item.uid : ""}: ${item.error}`;
      result.appendChild(line);
    });
    toast(`Imported ${r.success}; failed ${r.failed}`, r.failed ? "err" : "ok");
    $("accountsJson").value = "";
  } catch (err) {
    result.textContent = err.message || "Upload failed";
    result.className = "upload-result err";
    toast(err.message || "Upload failed", "err");
  } finally {
    btn.disabled = false;
    btn.textContent = "Upload & Login Accounts";
  }
});

/* ------------------------- search / tabs ------------------------- */
$("search").addEventListener("input", (e) => { state.search = e.target.value; render(); });
$("tabs").addEventListener("click", (e) => {
  const t = e.target.closest(".tab");
  if (!t) return;
  state.filter = t.getAttribute("data-filter");
  document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === t));
  render();
});

/* ------------------------- logout ------------------------- */
$("logoutBtn").addEventListener("click", async () => {
  try { await api("/api/auth/logout", { method: "POST" }); } catch (e) {}
  window.location.href = "/login";
});

/* ------------------------- websocket ------------------------- */
function connectWS() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);
  ws.onmessage = (ev) => {
    let msg = null;
    try { msg = JSON.parse(ev.data); } catch (e) { return; }
    if (msg.type === "snapshot") {
      state.accounts = {};
      (msg.accounts || []).forEach((a) => (state.accounts[a.uid] = a));
      render();
    } else if (msg.type === "account" && msg.account) {
      state.accounts[msg.account.uid] = msg.account;
      render();
    } else if (msg.type === "status" && msg.uid) {
      const a = state.accounts[msg.uid];
      if (a) { a.status = msg.status; render(); }
    } else if (msg.type === "removed" && msg.uid) {
      delete state.accounts[msg.uid]; render();
    } else if (msg.type === "log" && msg.uid) {
      const a = state.accounts[msg.uid];
      if (a) {
        a.logs = (a.logs || []).concat([{ t: msg.t, msg: msg.msg }]).slice(-60);
        if (state.openLogs[msg.uid]) {
          const panel = document.querySelector(`.logs-panel[data-logs="${msg.uid}"]`);
          if (panel) {
            const ln = document.createElement("div");
            ln.className = "ln"; ln.textContent = msg.msg;
            panel.appendChild(ln);
            panel.scrollTop = panel.scrollHeight;
          }
        }
      }
    }
  };
  ws.onclose = () => setTimeout(connectWS, 2500);
  ws.onerror = () => { try { ws.close(); } catch (e) {} };
}

/* ------------------------- init ------------------------- */
async function init() {
  try {
    const me = await api("/api/auth/me");
    state.user = me.user;
    $("userTag").textContent = "Signed in as " + me.user.username;
  } catch (e) { return; }

  try {
    const r = await api("/api/regions");
    state.regions = r.regions || [];
    const sel = $("region");
    sel.innerHTML = state.regions.map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join("");
    sel.value = "ME";
  } catch (e) {}

  try {
    const r = await api("/api/accounts");
    state.accounts = {};
    (r.accounts || []).forEach((a) => (state.accounts[a.uid] = a));
    render();
  } catch (e) {}

  connectWS();
}
init();
